class Main {
  public static void main(String[] args) {
    int Idade=0;

    System.out.println("Digite idade:%d");

    if(Idade>18 && Idade<=65){
        System.out.println("Eleitor obrigatorio\n");
    }
    else if(Idade>=16 && Idade<=18 || Idade>65){
        System.out.println("Eleitor facultativo\n");
    }
    else
    {
        System.out.println("Nao eleitor\n");
    }

    return 0;
}
}
