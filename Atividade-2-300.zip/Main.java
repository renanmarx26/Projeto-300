import java.util.Scanner;

class Main {  

 public static void main(String args[]) {

   Scanner sc = new Scanner(System.in);

   float nota;
   float sum = 0;
   float media;
   int[] array = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

   for(int i = 1; i <= 10; i++){

     System.out.println("Insira a nota %dº: ", i);

     nota = sc.nextFloat();

sum+=nota;

   }

   float media = sum/10;

   System.out.println("A média das notas são: " + media);

   

   
 }
}