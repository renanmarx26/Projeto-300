class Main {
  public static void main(String[] args) {
BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    
  System.out.println("Enter the octal number:");
    
  String oct = reader.readLine();
  int i= Integer.parseInt(oct,8);
  System.out.println("Decimal:=" + i);

    while ((!(ano % 4)) && (ano % 100) ) || (!(ano % 400)) {
            System.out.println("Ano bissexto: " + ano);
            
        }
  }
}
