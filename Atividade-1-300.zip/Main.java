import java.util.Scanner;

class Main {  

 public static void main(String args[]) {

   Scanner sc = new Scanner(System.in);

   float nota;
   float sum = 0;
   float media;

   for(int i = 1; i <= 10; i++){

     System.out.printf("Insira a %dº nota: ", i);

     nota = sc.nextFloat();

sum+=nota;

   }

   float media = sum/10;

   System.out.printf("A média das notas são: " + media);

 }
}