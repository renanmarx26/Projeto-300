class Main {
   public static void main(String args[]) {

    int segundos, h, m, s, resto;
    Scanner sc = new Scanner(System.in);

    System.out.println("Digite uma quantidade de segundos: %d" + segundos);
    
    h = segundos / 3600;
    resto = segundos % 3600;
    m = resto / 60;
    s = resto % 60;
    System.out.println("%d:%d:%d\n", h, m, s);

    return 0;
}
}